using System.Collections.Generic;
using Unity.Collections;
using Unity.Mathematics;
using UnityEngine;

namespace SeaSick.Ocean
{
    /// The one place ocean queries happen during physics (D5): every
    /// BuoyantBody probe and every registry handle is gathered into a single
    /// SampleBatch per FixedUpdate, completed, and distributed back. Nothing
    /// else samples in a loop.
    [DefaultExecutionOrder(-90)]
    public class OceanPhysicsDriver : MonoBehaviour
    {
        static readonly List<BuoyantBody> bodies = new List<BuoyantBody>();

        NativeArray<float3> queries;
        NativeArray<OceanSample> results;
        Vector3[] scratch = new Vector3[64];

        public static void Register(BuoyantBody b)
        {
            if (!bodies.Contains(b)) bodies.Add(b);
        }

        public static void Unregister(BuoyantBody b) => bodies.Remove(b);

        void OnDisable()
        {
            if (queries.IsCreated) queries.Dispose();
            if (results.IsCreated) results.Dispose();
        }

        [Header("Hull-length filtering")]
        [Tooltip("How much of cascade 1 (16-64 m waves) the hull feels. A ship of length L averages a wave of length lambda over her waterline, which multiplies the heave force by roughly sin(pi L/lambda)/(pi L/lambda) -- about 0.29 for a 24 m hull against this band. 1 = the raw surface (what is drawn), 0 = the hull ignores that band entirely.")]
        [SerializeField, Range(0f, 1f)] float hullFeelsCascade1 = 0.3f;
        [Tooltip("Same for the long swell. A 280 m roller is nearly flat under 24 m of hull, so this should stay at 1 -- the swell is what she is supposed to ride.")]
        [SerializeField, Range(0f, 1f)] float hullFeelsCascade0 = 1f;

        float2 HullFilter() => new float2(hullFeelsCascade0, hullFeelsCascade1);

        /// The filter the hull probes are sampled through, for the one other
        /// thing that has to agree with them: the motor's read of the face she
        /// is on. Raw if there is no driver, which is what it always was.
        public static float2 HullFilterNow =>
            instance != null ? instance.HullFilter() : OceanSampler.NoHullFilter;
        static OceanPhysicsDriver instance;
        void OnEnable() => instance = this;

        void FixedUpdate()
        {
            if (!OceanSampler.Ready) return;

            var registry = OceanProbeRegistry.Handles;
            int count = registry.Count;
            foreach (var b in bodies) count += b.Probes.Count;
            if (count == 0) return;

            // Grow-only. Cannonballs, crew and raiders register and unregister
            // as they come and go, so the count moves every few frames in a
            // fight; reallocating two persistent arrays on every change was a
            // native alloc + dispose per shot. Capacity doubles and stays.
            if (!queries.IsCreated || queries.Length < count)
            {
                if (queries.IsCreated) { queries.Dispose(); results.Dispose(); }
                int cap = Mathf.NextPowerOfTwo(count);
                queries = new NativeArray<float3>(cap, Allocator.Persistent);
                results = new NativeArray<OceanSample>(cap, Allocator.Persistent);
            }

            int cursor = 0;
            foreach (var b in bodies)
            {
                int n = b.Probes.Count;
                if (scratch.Length < n) scratch = new Vector3[Mathf.NextPowerOfTwo(n)];
                b.FillQueries(new System.Span<Vector3>(scratch, 0, n));
                for (int i = 0; i < n; i++)
                    queries[cursor + i] = scratch[i];
                cursor += n;
            }
            for (int i = 0; i < registry.Count; i++)
                queries[cursor + i] = registry[i].position;

            // ONE job over the whole array, with a PER-QUERY filter split at
            // the boundary between hull probes and everything else (the fill
            // above puts the hulls first for exactly this reason).
            //
            // The hull gets the wave field FILTERED to what a 24 m ship can
            // actually feel: a hull spans most of a 30 m wave, so the crest
            // lifting the bow is largely cancelled by the trough under the
            // stern, and feeding probe points the raw surface hands her
            // short-wave forces a real hull averages away. At storm steepness
            // that is what drives her under. Flotsam and crates are small
            // enough to ride the chop and keep the raw field -- filtering a
            // floating crate would be wrong in the other direction.
            //
            // This used to be two batches, each Complete()d in turn, because
            // the filter lived on the field struct and so had to be per-job.
            // That cost two serial fences every physics step -- the second job
            // could not even be SCHEDULED until the first had fenced, though
            // they write disjoint sub-arrays -- and with Maximum Allowed
            // Timestep a terrain hitch replays several steps and pays for each.
            // Worse, the hull batch is only 12-14 probes, so at the old
            // innerloopBatchCount of 16 the entire ship ran as one batch on one
            // worker while the pool idled. One schedule, batch 4, one fence.
            int hullCount = cursor;
            OceanSampler.SampleBatch(queries.GetSubArray(0, count), results.GetSubArray(0, count),
                default, hullCount, HullFilter()).Complete();

            cursor = 0;
            var span = results.AsReadOnlySpan();
            foreach (var b in bodies)
            {
                int n = b.Probes.Count;
                b.ApplyForces(span.Slice(cursor, n));
                cursor += n;
            }
            int frame = Time.frameCount;
            for (int i = 0; i < registry.Count; i++)
            {
                registry[i].sample = results[cursor + i];
                registry[i].sampledFrame = frame;
            }
        }
    }
}
