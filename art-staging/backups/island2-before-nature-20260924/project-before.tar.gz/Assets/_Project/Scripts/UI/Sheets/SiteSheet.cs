using System.Collections.Generic;
using SeaSick.World;
using UnityEngine;
using UnityEngine.UIElements;

namespace SeaSick.UI.Sheets
{
    /// **The drawing on the ground: what it still wants, and the three things
    /// you can do about it.**
    ///
    /// Kevin, 2026-09-21: *"the blueprint should be pressable where it states
    /// how many resources it still needs and the option to cancel the build /
    /// move it."* The old camp bar answered that in a panel; this is the
    /// same three facts and the same two calls, unfolded beside the stakes
    /// instead of along the bottom of the screen, plus the one
    /// thing the old panel could not do -- put somebody on it.
    ///
    /// **It closes itself the frame the building goes up.** `BuildSite.Retire`
    /// destroys the drawing when the row is raised, and `StillValid` is that
    /// object plus the row: a sheet about a promise that has been kept has
    /// nothing left to say.
    public class SiteSheet : ISheetFramed
    {
        // --- the frame (2026-09-22, "one sheet, tabs") ----------------------
        //
        // **One section, so no tab strip.** A drawing on the ground is one
        // fact -- how far along it is -- and three verbs. A strip with a
        // single tab on it would be a label dressed as a control, so the
        // frame simply leaves it out.
        public string[] TabLabels => null;
        public int Tab => 0;
        public void SetTab(int index) { }
        public Color Accent => SheetTheme.Timber;

        public VisualElement BuildHeader() =>
            SheetKit.Header("going up", Title, SheetTheme.Timber, "⚒",
                () => Sheets.Close());

        /// The three verbs, pinned: staff it, call it off, put it somewhere
        /// else. Same calls as before -- they have simply stopped being the
        /// last thing you scroll to.
        public VisualElement BuildActions()
        {
            addHand = SheetKit.Btn("Add a hand", AddHand, true);
            return SheetKit.Actions(
                addHand,
                SheetKit.Btn("Cancel", CancelBuild, false, true),
                SheetKit.Btn("Move", MoveBuild, false, true));
        }

        readonly Outpost outpost;
        readonly BuildSite site;
        readonly string planId;
        readonly string label;

        /// **The row this sheet is about (2026-09-22).** A camp can queue
        /// several drawings now, so "the pending one" would open the wrong
        /// sheet the moment there were two: the sheet holds the row the
        /// tapped `BuildSite` carries, and every verb on it acts on THAT
        /// row.
        readonly PendingBuild row;

        public SiteSheet(Outpost o, BuildSite s)
        {
            outpost = o;
            site = s;
            planId = s != null ? s.PlanId : null;
            row = s != null ? s.Row : null;
            label = BuildPlans.Named(row != null ? row.planId : planId).label;
        }

        public string Title => string.IsNullOrEmpty(label) ? "blueprint" : label;

        public Vector3 AnchorWorld => site != null
            ? site.transform.position
            : (outpost != null ? outpost.CampCentre : Vector3.zero);

        /// The drawing is still standing and the row behind it is still open.
        public bool StillValid
        {
            get
            {
                if (outpost == null || site == null || row == null) return false;
                var l = outpost.Ledger;
                return l != null && l.sites != null && l.sites.Contains(row);
            }
        }

        PendingBuild Pending => row;

        // --- the pieces kept between refreshes ---------------------------------

        Label big;            // "60 %"
        Label who;            // "Bo is on it · about 2 days left"
        VisualElement ring;   // the bar standing in for a progress ring
        VisualElement chips;
        Button addHand;

        long chipsKey = long.MinValue;
        int ringKey = -99;

        public VisualElement Build()
        {
            big = null; who = null; ring = null; chips = null;
            chipsKey = long.MinValue;
            ringKey = -99;

            var root = new VisualElement();
            root.style.flexDirection = FlexDirection.Column;

            // **A ring is a bar you have not drawn yet.** The percentage is
            // the number the player reads; the bar under it is what makes it
            // a shape rather than a figure, and a real ring can replace both
            // without this file changing.
            big = SheetKit.Text("0%", true, false, 28f);
            ring = SheetBits.Holder();
            root.Add(SheetKit.Row(big, ring));

            who = SheetKit.Text("", false, true, 12f);
            root.Add(who);

            chips = SheetBits.Holder();
            root.Add(chips);

            Refresh();
            return root;
        }

        public void Refresh()
        {
            var l = outpost != null ? outpost.Ledger : null;
            var p = Pending;
            if (l == null || p == null) return;
            outpost.CatchUp();

            // **The percentage is the BUILDING alone** (Kevin's phone
            // playtest, 2026-09-23: *"the percentages also start going up
            // before resource quota is met"*). `Progress01` reads 0 % while
            // the plot is cleared and stocked -- the chips below count the
            // deliveries in whole units -- then 0 to 100 over the hammering.
            int pct = Mathf.RoundToInt(p.Progress01 * 100f);
            if (pct != ringKey)
            {
                ringKey = pct;
                if (big != null) big.text = pct + "%";
                SheetBits.Swap(ring, SheetKit.Bar(p.Progress01, SheetTheme.Timber, 10f));
            }

            int builders = l.HandsOn(OutpostOrder.Build);
            string first = null;
            foreach (var h in l.hands)
                if (h != null && h.order == OutpostOrder.Build) { first = h.name; break; }

            // The line under the percentage is the CLOCK; the note below is
            // who and what. Splitting them is what lets the note read as one
            // sentence -- "Bo is on it. Needs 5 timber, 3 stone." -- instead
            // of a row of half-facts joined by dots.
            string clock = DaysLeftLine(l, p, builders);
            // With nobody on it the clock has nothing to say that the note
            // below does not say better, so it says nothing.
            if (who != null) who.text = clock == Nobody ? "" : Cap(clock);

            string crew = builders == 0 ? "Nobody is on it"
                : builders == 1 ? $"{first} is on it"
                : $"{first} and {builders - 1} more are on it";

            int timberLeft = Mathf.Max(0, p.needed - p.done);
            int stoneLeft = Mathf.Max(0, p.stoneNeeded - p.stoneDone);
            // Brick is `BuildPlan.brickCost` reaching the site -- zero on
            // every plan today (BuildPlan.cs:80), so `p.brickNeeded` is zero
            // and this whole branch is dormant until an upgrade actually
            // prices itself in bricks.
            int brickLeft = Mathf.Max(0, p.brickNeeded - p.brickDone);
            long key = ((((long)p.done * 31 + p.stoneDone) * 31 + p.needed * 7 + p.stoneNeeded)
                       * 31 + builders) * 31 + (p.brickDone * 31 + p.brickNeeded);
            // The building phase moves without any counter moving, so the
            // key has to carry it or the sheet freezes at "stocked".
            key = key * 31 + Mathf.RoundToInt(p.Build01 * 100f);
            // **The CLEAR phase, 2026-09-23.** `ClearLeft` moves as hands
            // fell trees and break rocks well before a single log is
            // stocked -- without it in the key the sheet would freeze on
            // "clearing: 4 trees, 1 rock left" for the whole phase.
            key = key * 31 + p.ClearLeft;
            // Why it is not moving (hungry / waiting its turn), 2026-09-23.
            string stall = l.StallReason(p);
            key = key * 31 + stall.GetHashCode();
            if (key != chipsKey && chips != null)
            {
                chipsKey = key;
                chips.Clear();
                // **The delivered chips only appear once something has been
                // delivered.** "0 of 5 timber · 0 of 3 stone" over "Needs 5
                // timber and 3 stone" is the same sentence twice, and on a
                // site nobody has carried a log to yet the first of them is
                // pure noise.
                if (p.done > 0 || p.stoneDone > 0 || p.brickDone > 0)
                {
                    var row = new List<VisualElement>
                    {
                        SheetKit.Text($"{p.done} of {p.needed} timber", false, false, 12f),
                        p.stoneNeeded > 0
                            ? SheetKit.Text($"{p.stoneDone} of {p.stoneNeeded} stone", false, false, 12f)
                            : SheetKit.Text("", false, true, 12f),
                    };
                    if (p.brickNeeded > 0)
                        row.Add(SheetKit.Text($"{p.brickDone} of {p.brickNeeded} bricks", false, false, 12f));
                    chips.Add(SheetKit.Row(row.ToArray()));
                }
                // **The phase, in the site's own words** -- "clearing: 3
                // trees, 1 rock left" comes first (2026-09-23: the CLEAR
                // phase the villagers work through before a single log is
                // laid, `OutpostLedger.PendingBuild.Cleared`), then
                // "stocking 3/6 logs, 2/2 stone" or "building 40%". One
                // string, shared with the camp page (`FireSheet.Note`), so
                // the two cannot say different things about the same
                // drawing.
                chips.Add(SheetKit.Text(Cap(p.Cleared ? p.PhaseLine : ClearingLine(p)),
                    true, false, 13f));
                string need = !p.Stocked
                    ? NeedSentence(timberLeft, stoneLeft, brickLeft)
                    : p.Complete
                        ? "Everything is in and it is going up."
                        : "Everything it wants is here; now they raise it.";
                chips.Add(SheetKit.Note(crew + ". " + need));
                if (stall.Length > 0) chips.Add(SheetKit.Note(stall));
            }

            if (addHand != null)
                addHand.SetEnabled(SheetBits.FirstIdle(l) != null);
        }

        /// **"about 2 days left", out of the ledger's own trip-timing
        /// model (2026-09-23 rewrite).**
        ///
        /// A guess by construction -- the hands have to walk, the stock can
        /// run out, and a starving camp works at `WorkFactor` -- so it says
        /// "about". Since stocking became whole-armful trips timed by real
        /// walking distance (`OutpostLedger.Stations`, "trip timing"), the
        /// old per-day haul rates (`TimberPerHandPerDay` etc) no longer
        /// describe anything the ledger does, so the estimate is rebuilt out
        /// of the same arithmetic a trip is booked with: remaining units ->
        /// `ceil(remaining / Res.Armful(res))` trips, each trip's time from
        /// `OutpostLedger.TripDays` (the exact function `StartTimedTrip`
        /// pays with), summed and divided among the hands actually on the
        /// build order. `HaulDaysFor` below is the per-resource half of
        /// that; the two phases (haul the pile, then hammer it up) are
        /// added because the same hands do them one after the other.
        /// The one answer callers have to be able to recognise: it is the
        /// only one that is about the CREW rather than about the clock, and
        /// both sheets say that part in their own words instead.
        public const string Nobody = "nobody is building it";

        /// One game-hour, in days -- the "under an hour" floor below.
        /// `TimeOfDay.DayLength` cancels out of the ratio regardless of its
        /// value, so this needs no reference to it.
        const float HourInDays = 1f / 24f;

        public static string DaysLeftLine(OutpostLedger l, PendingBuild p, int builders)
        {
            if (p == null) return "not started";
            if (p.Complete) return "ready to raise";
            if (builders <= 0) return Nobody;

            // **The haul half, 0 once `Stocked`** -- `HaulDaysFor` returns 0
            // for a resource with nothing left, so this needs no separate
            // Stocked branch to skip it.
            float haulDays = HaulDaysFor(l, p, Res.Timber, Mathf.Max(0, p.needed - p.done))
                + HaulDaysFor(l, p, Res.Stone, Mathf.Max(0, p.stoneNeeded - p.stoneDone))
                + HaulDaysFor(l, p, Res.Brick, Mathf.Max(0, p.brickNeeded - p.brickDone));

            // **The building half.** `LabourNeeded` is hand-days; `built`
            // only accrues once stocked, so this is the whole clock on a
            // site still being stocked and just the remainder once it is.
            float buildDays = Mathf.Max(0f, p.LabourNeeded - p.built);

            // Both halves are person-days of work the crew can split, so
            // both divide by the same headcount -- the haul trips are not
            // run by one hand alone any more than the hammering is.
            float days = (haulDays + buildDays) / builders;

            if (p.Stocked)
            {
                if (days < HourInDays) return "under an hour of building left";
                if (days < 0.4f) return "nearly up";
                if (days < 0.75f) return "about half a day of building left";
                return $"about {days:0.#} days of building left";
            }

            if (days < HourInDays) return "under an hour left";
            if (days < 0.75f) return "about half a day left";
            if (days < 1.5f) return "about a day left";
            return $"about {days:0.#} days left";
        }

        /// **Person-days to haul the last `remaining` units of `res` to the
        /// site**, out of the same trips `OutpostLedger.StartSiteTrip` would
        /// actually start: the pile first, the island (cut/quarry) after.
        ///
        /// `StartSiteTrip` also tries a station's output rack between those
        /// two, but `OutpostLedger` has no public accessor for rack stock,
        /// so a rack-fed haul reads here as a slower Field (cut) trip --
        /// this estimate can run a little LONG on a camp with a stocked
        /// sawmill or quarry rack, never short. Brick has no Field step at
        /// all (`StartSiteTrip` never quarries a brick), so a brick short of
        /// the store's whole pile reads as a Store trip too rather than
        /// pretend it can be gathered -- a guess, but "empty" would be worse.
        static float HaulDaysFor(OutpostLedger l, PendingBuild p, string res, int remaining)
        {
            if (l == null || remaining <= 0) return 0f;
            int armful = Mathf.Max(1, Res.Armful(res));
            int fromStore = res == Res.Brick ? remaining
                : Mathf.Min(remaining, Mathf.Max(0, l.StoreCountOf(res)));
            int fromField = remaining - fromStore;
            int storeTrips = Mathf.CeilToInt(fromStore / (float)armful);
            int fieldTrips = Mathf.CeilToInt(fromField / (float)armful);
            float days = 0f;
            if (storeTrips > 0)
                days += storeTrips * l.TripDays(res, armful, HaulPlace.Store, -1, HaulPlace.Site, -1, p);
            if (fieldTrips > 0)
                days += fieldTrips * l.TripDays(res, armful, HaulPlace.Field, -1, HaulPlace.Site, -1, p);
            return days;
        }

        /// **"clearing: 3 trees, 1 rock left"** -- the CLEAR phase's own
        /// phase line, singular/plural correct, ahead of stocking/building
        /// in `p.PhaseLine`. Only ever asked for while `!p.Cleared`.
        static string ClearingLine(PendingBuild p)
        {
            var parts = new List<string>(2);
            if (p.TreesLeft > 0) parts.Add(p.TreesLeft == 1 ? "1 tree" : $"{p.TreesLeft} trees");
            if (p.RocksLeft > 0) parts.Add(p.RocksLeft == 1 ? "1 rock" : $"{p.RocksLeft} rocks");
            return parts.Count == 0 ? "clearing" : "clearing: " + string.Join(", ", parts) + " left";
        }

        static string Cap(string s) =>
            string.IsNullOrEmpty(s) ? s : char.ToUpperInvariant(s[0]) + s.Substring(1);

        /// "Needs 5 timber, 3 stone and 2 bricks." -- one clause per short
        /// pile that is still owed, joined the way a person would say them.
        /// Bricks come last: they are the one thing here nobody can walk out
        /// and gather (BuildPlan.cs:86), so the list ends on the part that is
        /// waiting on the fire's own stores rather than on a hand's back.
        static string NeedSentence(int timberLeft, int stoneLeft, int brickLeft)
        {
            var parts = new List<string>(3);
            if (timberLeft > 0) parts.Add($"{timberLeft} timber");
            if (stoneLeft > 0) parts.Add($"{stoneLeft} stone");
            if (brickLeft > 0) parts.Add($"{brickLeft} bricks");
            if (parts.Count == 0) return "Stocked, everything it wants is here.";
            if (parts.Count == 1) return $"Needs {parts[0]}.";
            if (parts.Count == 2) return $"Needs {parts[0]}, {parts[1]}.";
            return $"Needs {parts[0]}, {parts[1]} and {parts[2]}.";
        }

        // --- the three verbs ------------------------------------------------------

        /// The per-hand build order -- `Outpost.OrderBuild` (Outpost.cs:1680),
        /// which is what the Hand does when it drops somebody on a drawing.
        /// The crew list's build verb sites a NEW building; this one staffs
        /// the drawing that is already here.
        void AddHand()
        {
            var l = outpost != null ? outpost.Ledger : null;
            var free = SheetBits.FirstIdle(l);
            if (free == null) return;
            outpost.OrderBuild(free);
            Refresh();
        }

        /// `Outpost.CancelPending` -- the wood and stone already carried here
        /// go back on the pile.
        void CancelBuild()
        {
            if (outpost == null) return;
            outpost.CancelPending(row);
            Sheets.Close();
        }

        /// `CampSiting.Begin(..., movePending: true)` -- the drawing stays
        /// where it is until the new spot is tapped, so escaping the move
        /// leaves the camp exactly as it was.
        void MoveBuild()
        {
            var p = Pending;
            if (outpost == null || p == null) return;
            var plan = BuildPlans.Named(p.planId).WithLength(p.length);
            CampSiting.Begin(outpost, plan, SheetBits.ShipTransform, p);
            Sheets.Close();
        }
    }
}
