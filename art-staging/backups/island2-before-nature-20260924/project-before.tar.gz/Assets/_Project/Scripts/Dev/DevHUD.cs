using SeaSick.Crew;
using SeaSick.Ship;
using UnityEngine;

namespace SeaSick.Dev
{
    /// Development overlay: speed, sail, wind angle, and the roughness meter.
    /// IMGUI on purpose — zero setup, deleted before release. Toggle with F1.
    [RequireComponent(typeof(ShipMotor), typeof(SmoothnessMeter))]
    public class DevHUD : MonoBehaviour, SeaSick.UI.IDevTool
    {
        // Off by default now that StatusHUD owns the permanent readouts.
        // F1 brings back the full diagnostic wall when tuning — and now brings
        // it back INSIDE the settings drawer, which is a rect that nothing
        // else is using. It used to paint a black slab from (6,6) across 60 %
        // of the screen, straight over the crew pips and the compass tape.
        [SerializeField] bool visible = false;

        // --- IDevTool ---
        public string ToolName => "Dev HUD";
        public string ToolBlurb => "speed, engine, roughness, broach and every crew member's state (F1)";
        public bool ToolActive { get => visible; set => visible = value; }
        void OnEnable() => SeaSick.UI.DevTools.Register(this);
        void OnDisable() => SeaSick.UI.DevTools.Unregister(this);

        ShipMotor motor;
        SmoothnessMeter meter;
        Breakers breakers;
        CrewAgent[] crew;
        GUIStyle label;

        void Awake()
        {
            motor = GetComponent<ShipMotor>();
            meter = GetComponent<SmoothnessMeter>();
            breakers = GetComponent<Breakers>();
        }

        void Start() { crew = GetComponentsInChildren<CrewAgent>(); }

        void Update()
        {
            // **Editor and dev builds only, 2026-09-23.** The tuning list
            // inside the panel was already compiled out of a shipping build,
            // but this hotkey was not, so a keyboard on a release build could
            // still summon the diagnostic wall.
#if UNITY_EDITOR || DEVELOPMENT_BUILD
            var kb = UnityEngine.InputSystem.Keyboard.current;
            if (kb != null && kb.f1Key.wasPressedThisFrame)
                SeaSick.UI.SettingsPanel.Toggle(this);
#endif
        }

        public void DrawTool(Rect body)
        {
            const int FontSize = 16; // constant: view-size-derived values proved unreliable
            if (label == null || label.fontSize != FontSize)
                label = new GUIStyle(GUI.skin.label)
                {
                    fontSize = FontSize,
                    fontStyle = FontStyle.Bold,
                };

            // The drawer owns the panel and its background; this draws rows.
            float w = body.width;
            float x = body.x, y = body.y;
            const float line = FontSize * 1.7f;

            Vector3 fwd = motor.transform.forward;
            float windAngle = Vector3.SignedAngle(
                new Vector3(fwd.x, 0f, fwd.z),
                new Vector3(motor.WindDirection.x, 0f, motor.WindDirection.y),
                Vector3.up);

            GUI.Label(new Rect(x, y, w, line),
                $"speed {motor.CurrentSpeed:F1} m/s  ({motor.CurrentSpeed / motor.MaxSpeed:P0})   drift {motor.DriftAngleDeg:F0}°", label);
            string gust = motor.GustFactor01 > 0.1f ? $"   GUST ×{motor.WindStrength:F2}" : "";
            GUI.Label(new Rect(x, y += line, w, line),
                $"engine {motor.Throttle:P0}   wind {windAngle:F0}° off bow{gust}", label);
            var hull = motor.GetComponent<HullIntegrity>();
            string hullText = hull != null ? $"   hull {hull.Integrity01:P0}" : "";
            GUI.Label(new Rect(x, y += line, w, line),
                $"roughness {meter.Roughness01:F2}{hullText}", label);

            // The six things that decide whether a wave is worth riding.
            // Without these on screen a playtest of the broach is a report
            // that something felt odd, which is not a measurement.
            string ease = motor.Easing ? $"  ease -{motor.EaseCost01:P0}" : "";
            GUI.Label(new Rect(x, y += line, w, line),
                $"broach {motor.Broach01:F2}   overspeed {motor.Overspeed01:F2}   " +
                $"run {motor.SurfRunSeconds:F1}s{ease}", label);

            string surf = breakers != null && breakers.Breaking01 > 0.005f
                ? $"   BREAKERS {breakers.Breaking01:F2} under {breakers.DepthUnderKeel:F1} m"
                : "";
            GUI.Label(new Rect(x, y += line, w, line),
                $"sea {motor.SeaHs:F1} m ({motor.SeaStateName})  resist {motor.SeaResistance01:P0}   " +
                $"wind {motor.SeaAngleDeg:F0}° swell {motor.SwellAngleDeg:F0}° off bow{surf}", label);

            // Roughness bar: green calm, red rough.
            var barRect = new Rect(x, y + line * 1.1f, w, line * 0.5f);
            GUI.color = new Color(0f, 0f, 0f, 0.4f);
            GUI.DrawTexture(barRect, Texture2D.whiteTexture);
            GUI.color = Color.Lerp(new Color(0.3f, 0.85f, 0.35f), new Color(0.9f, 0.25f, 0.2f), meter.Roughness01);
            GUI.DrawTexture(new Rect(barRect.x, barRect.y, barRect.width * meter.Roughness01, barRect.height),
                Texture2D.whiteTexture);
            GUI.color = Color.white;

            if (crew == null) return;
            y = barRect.yMax + line * 0.2f;
            foreach (var c in crew)
            {
                if (c == null) continue;
                string who = c.Def != null ? c.Def.displayName : "crew";
                GUI.Label(new Rect(x, y, w, line),
                    $"{who}: sick {c.Sickness01:F2}  work {c.WorkRate01:F2}  [{c.StateName}]", label);
                var sickRect = new Rect(x, y + line, w, line * 0.4f);
                GUI.color = new Color(0f, 0f, 0f, 0.4f);
                GUI.DrawTexture(sickRect, Texture2D.whiteTexture);
                GUI.color = Color.Lerp(new Color(0.85f, 0.75f, 0.4f), new Color(0.45f, 0.8f, 0.3f), c.Sickness01);
                GUI.DrawTexture(new Rect(sickRect.x, sickRect.y, sickRect.width * c.Sickness01, sickRect.height),
                    Texture2D.whiteTexture);
                GUI.color = Color.white;
                y += line * 1.75f;
            }
        }
    }
}
