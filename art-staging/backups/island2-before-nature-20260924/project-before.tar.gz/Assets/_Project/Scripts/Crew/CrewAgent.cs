using System.Collections.Generic;
using SeaSick.Ship;
using UnityEngine;

namespace SeaSick.Crew
{
    /// One crew member on deck.
    ///
    /// **Seasickness is characterisation, not a mechanic.** It tracks how
    /// rough the sea is right now — they go green and unsteady in a bad sea
    /// and get their colour back in calm water — and it costs the player
    /// nothing at all. It reads the weather on their faces, which is worth
    /// keeping; it is no longer a clock, and it never takes anyone off a post.
    /// (The hook is deliberately left here for a future crew-happiness system.)
    ///
    /// What DOES take them off a post is work: hands on the buckets are hands
    /// off the guns. That is the real cost now, and the player causes it by
    /// loading the ship.
    ///
    /// Lives as a child of the ship, so deck motion comes for free.
    public class CrewAgent : MonoBehaviour
    {
        [Header("Who")]
        [SerializeField] CrewMemberDef def;

        [Header("Sickness (cosmetic only)")]
        [Tooltip("How green a really foul sea makes them. Pure characterisation — costs nothing.")]
        [SerializeField] float sicknessAtWorstSea = 1f;
        [Tooltip("Seconds to go green in a bad sea, and to get their colour back in a calm one.")]
        [SerializeField] Vector2 sicknessHalflife = new Vector2(22f, 45f);

        [Header("Heaving (cosmetic only)")]
        [Tooltip("How queasy before they start retching. They never leave their post to do it.")]
        [SerializeField] float heaveThreshold = 0.72f;
        [Tooltip("Seconds between heaves, at the threshold and at the very worst.")]
        [SerializeField] Vector2 heaveInterval = new Vector2(26f, 7f);
        [SerializeField] float heaveLength = 2.2f;

        [Header("Deck positions (ship-local)")]
        [SerializeField] Vector3 stationLocal = new Vector3(1.0f, 2.0f, -2.5f);
        [SerializeField] Vector3 railLocal = new Vector3(1.8f, 2.0f, -2.5f);
        [SerializeField] float walkSpeed = 1.4f;

        [Header("Shore leave")]
        [SerializeField] float shoreWalkSpeed = 6.5f;
        [SerializeField] float swingInterval = 0.42f;

        [Header("Bailing")]
        [Tooltip("How far inboard of their station they step to work a bucket.")]
        [SerializeField] float bailStepInboard = 0.55f;

        [Header("Acting")]
        [Tooltip("ONLY the skin renderer. The tint below is the crew member's " +
                 "skin colour, so pointing this at the clothes turns the whole " +
                 "man green instead of just his face and forearms.")]
        [SerializeField] Renderer[] tintRenderers;
        [Tooltip("Left empty, it is found on the visual child.")]
        [SerializeField] Animator animator;
        [SerializeField] Color healthyTint = new Color(0.87f, 0.65f, 0.48f);
        [SerializeField] Color sickTint = new Color(0.55f, 0.78f, 0.45f);
        [SerializeField] float maxSwayDegrees = 9f;

        /// How green they look. Cosmetic: drives tint, sway and retching, and
        /// nothing else. Tracks the sea rather than accumulating.
        public float Sickness01 { get; private set; }
        public int PukeCount { get; private set; }
        public string StateName => state.ToString();
        public CrewMemberDef Def => def;
        public string DisplayName => def != null ? def.displayName : name;

        /// **Give a body somebody to be.** For figures made at runtime --
        /// villagers recruited by a camp (`BornVillager`) -- whose def is a
        /// fresh instance rather than an authored asset. The authored crew
        /// keep the def the scene gave them and never call this.
        public void SetDef(CrewMemberDef who)
        {
            if (who == null) return;
            def = who;
        }

        /// **This is your deck now.**
        ///
        /// `ship` is read off the parent in Awake, which is right for a hand
        /// who was born a child of the hull and wrong for one who was born at
        /// a camp: his "ship" would be the outpost, and `PutBackOnStation`
        /// would walk him off the deck and back into the fire ring. Carrying
        /// somebody aboard therefore says so, and the spot he is standing on
        /// becomes the post he keeps.
        public void BoardShip(Transform hull, Vector3 stationLocalPos)
        {
            ship = hull;
            stationLocal = stationLocalPos;
            railLocal = stationLocalPos + new Vector3(0.6f, 0f, 0f);
            PutBackOnStation();
        }

        /// Standing at their post and free to work it. Bailing, ashore, or
        /// over the side means no — this is the single question every ship
        /// system asks before it does anything. Being sick is NOT a reason.
        public bool Available => state == State.Station;

        /// **Something else is moving this body.** Set by `World.CampWorker`
        /// (and the Hand) for as long as they drive the transform of a hand
        /// parked at a camp. A parked hand's state is `Station`, and `Station`
        /// both writes the body's rotation every frame and counts as being at
        /// sea — neither of which is true of somebody walking to a sawmill.
        ///
        /// Two things honour it, and only two: `ActBody` leaves the root
        /// rotation alone (the tint is untouched, so the sea still shows on
        /// their faces), and `TrackSickness` treats them as ashore. The state
        /// machine is NOT bypassed — `Station` does nothing anyway, and the
        /// walk cycle is driven by how fast the body is actually moving, so
        /// the legs come along for free however something else moves them.
        public bool Puppeted { get; set; }

        /// How fast they work when they are working. Flat: a queasy hand is
        /// still a hand. Kept as a seam for a future happiness/skill system.
        public float WorkRate01 => state == State.Station ? 1f : 0f;

        /// On a bucket instead of their post.
        public bool IsBailing => state == State.Bailing;

        /// Where this one starts retching — spread across the crew so five
        /// people don't heave on the same frame.
        float HeaveAt => Mathf.Clamp01(
            heaveThreshold + 0.1f * (def != null ? def.ironStomach : 0f) + pukeJitter);

        /// 0 at the threshold, 1 at the worst — drives how often.
        float Severity01 => Mathf.InverseLerp(HeaveAt, 1f, Sickness01);

        /// Called when the ship docks at home.
        public void Rest()
        {
            Sickness01 = 0f;
            if (IsAboard) ReturnToStation();
        }

        /// Put them on a bucket. Ignored if they aren't aboard.
        public void StartBailing()
        {
            if (state == State.Station || state == State.Returning) state = State.Bailing;
        }

        /// Take them off the buckets and send them back to their post.
        public void StopBailing()
        {
            if (state == State.Bailing) state = State.Returning;
        }

        /// Put them back at their post, wherever they were and whatever they
        /// were doing.
        ///
        /// Unlike `ReturnAboard`, which makes them WALK back, this is for the
        /// cases where the body has been moved by something else -- parked at
        /// a camp and brought back aboard, restored from a save -- and the
        /// state machine has to agree with where the transform now is rather
        /// than path to it.
        public void PutBackOnStation()
        {
            ReleaseNode();
            state = State.Station;
            carriedResource = null;
            if (carried != null) { Destroy(carried); carried = null; }
            if (ship != null)
            {
                transform.SetParent(ship, true);
                transform.localPosition = stationLocal;
                transform.localRotation = Quaternion.identity;
            }
        }

        /// Thrown across the deck — running aground rattles them badly. Now
        /// permanent progress up the meter, so every hit spends the voyage.
        public void Jolt(float amount) => Sickness01 = Mathf.Clamp01(Sickness01 + amount);

        /// Post this hand to a station — used by CannonBattery to stand each
        /// gunner at their own gun. Taken from the live gun transforms rather
        /// than baked into the scene, so the deck can never drift out of sync
        /// with where the guns actually are.
        public void AssignStation(Vector3 station, Vector3 rail)
        {
            stationLocal = station;
            railLocal = rail;
            // Script order isn't guaranteed, so this can land before or after
            // Start: snap them over if they're just standing about.
            if (state == State.Station) transform.localPosition = stationLocal;
        }

        enum State
        {
            Station, Bailing, Returning,                 // aboard
            GoingAshore, ToNode, Chopping, ToShip, Idling, Boarding
        }
        State state = State.Station;

        /// Ashore covers the whole work loop, not just standing about.
        public bool IsAshore => state == State.ToNode || state == State.Chopping
            || state == State.ToShip || state == State.Idling || state == State.GoingAshore;
        public bool IsAboard => state == State.Station || state == State.Bailing
            || state == State.Returning;

        Transform ship;
        Vector3 shoreTarget;
        World.Island workIsland;
        Ship.ShipHold hold;
        Ship.Gangway gangway;
        Voyage.VoyageManager voyage;

        World.ResourceNode targetNode;
        GameObject carried;
        string carriedResource;
        int hitsLeft;
        float swingTimer;

        /// Send this crew member ashore to work an island.
        public void GoAshore(Vector3 landingPoint, World.Island island,
            Ship.ShipHold shipHold, Ship.Gangway plank, Voyage.VoyageManager voyageManager)
        {
            if (IsAshore) return;
            ship = transform.parent;
            shoreTarget = landingPoint;
            workIsland = island;
            hold = shipHold;
            gangway = plank;
            voyage = voyageManager;
            transform.SetParent(null, true);
            transform.localRotation = Quaternion.identity;
            // Both footing caches are about WHERE THEY ARE, and they are about
            // to be somewhere else. Forced stale rather than trusted: the
            // throttles are an optimisation, and an optimisation that survives
            // a teleport is a bug.
            nextIsleLookup = 0f;
            groundHeld = false;
            groundTickEnd = 0f;
            PathToShore(landingPoint);
            state = State.GoingAshore;
        }

        /// Recall to the ship. Drops any claim and walks back.
        public void ReturnAboard()
        {
            if (!IsAshore) return;
            ReleaseNode();
            PathToShip(ship != null ? ship.TransformPoint(stationLocal) : transform.position);
            state = State.Boarding;
        }

        void ReleaseNode()
        {
            if (targetNode != null) targetNode.Release(this);
            targetNode = null;
        }

        /// Look for the next thing to cut. Nothing left means idle on the beach.
        void SeekWork()
        {
            if (workIsland == null || (voyage != null && voyage.HoldFull))
            {
                state = State.Idling;
                return;
            }
            targetNode = World.ResourceNode.FindFree(workIsland, transform.position, this);
            state = targetNode != null ? State.ToNode : State.Idling;
        }

        void PickUp(string resource)
        {
            carriedResource = resource;
            carried = World.CargoVisual.Build(resource, transform);
            carried.transform.localPosition = new Vector3(0f, 1.45f, 0.45f);
            carried.transform.localScale = Vector3.one * 0.7f;
        }

        void DropOff()
        {
            if (carried != null) Destroy(carried);
            carried = null;
            if (string.IsNullOrEmpty(carriedResource)) { carriedResource = null; return; }

            // **A camp takes what is cut on its own island.**
            //
            // Without this the ship's party carries wood past a fire that
            // exists to keep exactly that, and straight into the hold — which
            // makes the camp an ornament on the island it is standing on.
            //
            // There is no double-counting to worry about, and the reason is
            // worth stating: the ledger counts only the hands who LIVE here,
            // and a hand walking about is by definition not one of them. A
            // stationed hand is a row that produces arithmetically; a visiting
            // hand is a body that delivers. The two sets never overlap.
            var camp = workIsland != null ? World.Outpost.Of(workIsland) : null;
            if (camp != null && camp.Ledger != null)
            {
                camp.CatchUp();
                var l = camp.Ledger;

                // **A blueprint is paid before a pile is filled.** A hand who
                // walked a log past the half-built fire and stacked it beside
                // one is the same nonsense as carrying it past the camp into
                // the hold, one step further in. This is also the whole of how
                // a VISITING hand helps build: the stationed rows accrue
                // through the tick, the bodies deliver through here, and the
                // two never double-count because a hand who lives here is a
                // row and a hand walking about is not.
                // Only the stuff it is actually built OUT of. A hand carrying
                // ore past a half-built shed is not paying for it, and before
                // resources were per-kind this branch happily let him.
                if (l.Building
                    && carriedResource == World.BuildPlans.Named(l.Pending.planId).resource)
                {
                    // Through the ledger's door, not a bare increment: the
                    // oldest site short of this material takes it, and a
                    // site already stocked spills it to the pile instead of
                    // counting past its need (Kevin, 2026-09-23).
                    l.DeliverToSite(carriedResource, 1);
                    carriedResource = null;
                    // The last log finishes it, and the fire should be alight
                    // before the man has walked away from it.
                    camp.CatchUp();
                    return;
                }

                // **Per resource, not per camp.** Ten of each is what the fire
                // watches over, so a hand carrying ore past a full timber pile
                // still has somewhere to put it.
                if (camp.HasCamp && l.Add(carriedResource, 1) > 0)
                {
                    carriedResource = null;
                    return;
                }
                // The pile is full. Fall through: better in the hold than
                // vanished, and a full camp is exactly when you want the wood
                // on the ship anyway.
            }

            if (voyage != null)
            {
                voyage.AddLoot(1, carriedResource);
                if (hold != null) hold.AddVisual(carriedResource);
            }
            carriedResource = null;
        }

        SmoothnessMeter meter;
        Ship.ShipMotor motor;
        float walkSpeedSeen;      // metres/second, smoothed, for the Animator
        Vector3 lastSample;
        bool sampledAshore;
        bool sampled;
        static readonly int SpeedId = Animator.StringToHash("Speed");
        MaterialPropertyBlock block;
        float heaveTimer;     // time left in the current retch
        float heaveCooldown;  // time until the next one
        float pukeJitter;
        float swayPhase;
        static readonly int BaseColorId = Shader.PropertyToID("_BaseColor");

        // ------------------------------------------------- what is underfoot
        //
        // A shore party walking over water used to make THREE managed calls
        // per agent per frame from WalkToWorld: an un-Bursted
        // `OceanSampler.SampleImmediate`, an `Island.Nearest` scan of every
        // island, and a delegate into the terrain height field. The immediate
        // sample is the expensive one — the cost probe counted 14 a frame at
        // sea against the 8 the sampler's own doc budgets for, at ~42 us each
        // — and a full shore party over the water spends that budget on feet.
        // StormSpray moved its 24 immediate samples into the registry and got
        // 1.0 ms a frame back; this is the same move.
        //
        // The other two are throttled rather than batched: nothing was wrong
        // with them but the rate.

        /// One handle per hand, folded into the ONE batched Burst query the
        /// physics driver runs per step. Only read while they are over water.
        Ocean.OceanProbeRegistry.Handle seaProbe;

        /// Which island they are walking on. Re-resolved twice a second: at
        /// 6.5 m/s that is three metres of walking, and `Nearest` answers with
        /// the island whose SHORELINE is closest — an answer that does not
        /// change hands over three metres unless they are already in the
        /// strait between two, where either gives the same footing. The
        /// shoreline test itself stays per-frame (see WalkToWorld): it is an
        /// array index, and it is the call that decides water from land.
        World.Island footingIsle;
        float nextIsleLookup;
        const float IsleInterval = 0.5f;

        /// The terrain height, sampled at 10 Hz and interpolated across the
        /// gap. Simply HOLDING the last value would trade the per-frame cost
        /// for a lag that grows with the slope being crossed — the error the
        /// big comment in WalkToWorld was written about. So each tick samples
        /// where they will BE when it expires and the frames between walk the
        /// straight line to it: no lag at all on a straight leg, and at worst
        /// one tick of a turn to catch up.
        float groundFrom, groundTo, groundTickEnd;
        bool groundHeld;
        const float GroundInterval = 0.1f;

        void OnEnable()
        {
            seaProbe = Ocean.OceanProbeRegistry.Register(transform.position);
        }

        void OnDisable()
        {
            Ocean.OceanProbeRegistry.Unregister(seaProbe);
            seaProbe = null;
        }

        /// Re-registered rather than assumed: a domain reload mid-play empties
        /// the registry's static list while the component and this field
        /// survive. StormSpray.EnsureHandles documents the same asymmetry.
        void EnsureProbe()
        {
            if (seaProbe != null && Ocean.OceanProbeRegistry.Handles.Count > 0) return;
            seaProbe = Ocean.OceanProbeRegistry.Register(transform.position);
        }

        void Start()
        {
            meter = GetComponentInParent<SmoothnessMeter>();
            motor = GetComponentInParent<Ship.ShipMotor>();
            block = new MaterialPropertyBlock();
            if (tintRenderers == null || tintRenderers.Length == 0)
                tintRenderers = FindSkinRenderers();
            if (animator == null) animator = GetComponentInChildren<Animator>();
            transform.localPosition = stationLocal;
            // Seeded off the name so a given crew member always breaks at the
            // same point — variety between people, not between playthroughs.
            pukeJitter = (Mathf.Abs(DisplayName.GetHashCode() % 100) / 100f - 0.5f) * 0.08f;
        }

        void Update()
        {
            float dt = Time.deltaTime;
            TrackSickness(dt);
            TickHeaving(dt);
            RunStateMachine(dt);
            TrackWalking(dt);
            ActBody(dt);
        }

        /// The walk cycle is driven by how fast they are ACTUALLY moving, not
        /// by a list of states that walk. Every state that moves them does it
        /// through one of the Walk* helpers, so measuring the result cannot
        /// fall out of step the way an enumeration would the next time a state
        /// is added.
        ///
        /// The frame matters and is not cosmetic: aboard, they are children of
        /// a ship that is itself doing 15 m/s, so world-space movement would
        /// have the whole watch sprinting on the spot the moment she got under
        /// way. Aboard, measure in the SHIP's frame — which is the frame
        /// WalkTo moves them in anyway.
        void TrackWalking(float dt)
        {
            if (dt <= 0f) return;
            bool ashore = IsAshore;
            Vector3 here = ashore ? transform.position : transform.localPosition;
            float raw = 0f;
            if (sampled && ashore == sampledAshore)
                raw = (here - lastSample).magnitude / dt;
            lastSample = here;
            sampledAshore = ashore;
            sampled = true;

            // Doubled over the side is not walking, whatever their feet did
            // the frame before.
            if (heaveTimer > 0f) raw = 0f;
            walkSpeedSeen = Mathf.Lerp(walkSpeedSeen, raw, 1f - Mathf.Exp(-10f * dt));
            if (animator != null) animator.SetFloat(SpeedId, walkSpeedSeen);
        }

        /// The tint is a SKIN colour, so it must reach skin and nothing else.
        /// The old fallback took every renderer on the object, which was right
        /// when a crew member was a sphere and a capsule and is now the
        /// difference between a queasy man and a man in a green shirt.
        Renderer[] FindSkinRenderers()
        {
            var all = GetComponentsInChildren<Renderer>();
            var skin = new List<Renderer>();
            foreach (var r in all)
            {
                var m = r.sharedMaterial;
                if (m != null && m.name.IndexOf("skin", System.StringComparison.OrdinalIgnoreCase) >= 0)
                    skin.Add(r);
            }
            return skin.Count > 0 ? skin.ToArray() : all;
        }

        /// Sickness now READS the sea rather than counting time on it: it
        /// eases toward however rough things are right now, quickly on the way
        /// up and slowly on the way down, so a squall turns the deck green and
        /// a calm hour gives them their colour back. Ashore they settle.
        void TrackSickness(float dt)
        {
            float target;
            // A hand parked at a camp is standing on an island. Their state is
            // `Station`, because that is what a body switched off at a camp
            // is, and without this they would go on being measured against
            // the sea the ship is in three kilometres away.
            if (IsAshore || Puppeted) target = 0f;
            else
            {
                float rough = meter != null ? meter.Roughness01 : 0f;
                float resistance = def != null ? def.ironStomach : 0f;
                target = sicknessAtWorstSea * rough * rough * (1f - 0.5f * resistance);
            }

            float halflife = target > Sickness01 ? sicknessHalflife.x : sicknessHalflife.y;
            float blend = 1f - Mathf.Exp(-(0.6931f / Mathf.Max(0.01f, halflife)) * dt);
            Sickness01 = Mathf.Clamp01(Mathf.Lerp(Sickness01, target, blend));
        }

        void RunStateMachine(float dt)
        {
            switch (state)
            {
                case State.Station:
                    break;

                case State.Bailing:
                    // They step inboard off their post and work a bucket. The
                    // gun behind them is silent for exactly as long as this
                    // lasts, which is the whole cost of a wet ship.
                    WalkTo(BailLocal, dt);
                    break;

                case State.Returning:
                    if (WalkTo(stationLocal, dt))
                    {
                        transform.localRotation = Quaternion.identity;
                        state = State.Station;
                    }
                    break;

                case State.GoingAshore:
                    if (FollowPath(dt, 0.4f)) SeekWork();
                    break;

                case State.ToNode:
                    if (targetNode == null || targetNode.Harvested) { SeekWork(); break; }
                    // Stop a pace short so they stand beside the tree, not in it.
                    if (WalkNear(targetNode.transform.position, 1.9f, dt))
                    {
                        hitsLeft = targetNode.HitsToHarvest;
                        swingTimer = 0f;
                        state = State.Chopping;
                    }
                    break;

                case State.Chopping:
                {
                    if (targetNode == null || targetNode.Harvested) { SeekWork(); break; }
                    swingTimer -= dt;
                    if (swingTimer <= 0f)
                    {
                        swingTimer = swingInterval;
                        targetNode.Strike();
                        hitsLeft--;
                        if (hitsLeft <= 0)
                        {
                            string res = targetNode.Resource;
                            targetNode.Harvest();
                            if (workIsland != null) workIsland.Extract(1f);
                            targetNode = null;
                            PickUp(res);
                            PathToShip(hold != null ? hold.DropPoint
                                : (ship != null ? ship.TransformPoint(stationLocal) : transform.position));
                            state = State.ToShip;
                        }
                    }
                    // Lean into the swing.
                    float swing = Mathf.Sin(Time.time * 12f) * 16f;
                    Vector3 face = targetNode != null
                        ? targetNode.transform.position - transform.position : transform.forward;
                    face.y = 0f;
                    if (face.sqrMagnitude > 0.01f)
                        transform.rotation = Quaternion.LookRotation(face, Vector3.up)
                            * Quaternion.Euler(swing, 0f, 0f);
                    break;
                }

                case State.ToShip:
                    RefreshShipWaypoints(hold != null ? hold.DropPoint : Vector3.zero, hold != null);
                    if (FollowPath(dt, 1.2f))
                    {
                        DropOff();
                        SeekWork();
                    }
                    break;

                case State.Idling:
                    // Nothing to cut — wait on the beach, and pick work back up
                    // if the hold empties or another node frees.
                    transform.rotation = Quaternion.Euler(
                        0f, Mathf.Sin(Time.time * 0.6f + shoreTarget.x) * 40f, 0f);
                    swingTimer -= dt;
                    if (swingTimer <= 0f) { swingTimer = 1.5f; SeekWork(); }
                    break;

                case State.Boarding:
                    if (ship == null) { ReturnToStation(); break; }

                    // The last waypoint is the station, but the ship is moving
                    // on the swell, so keep it current as we approach.
                    RefreshShipWaypoints(ship.TransformPoint(stationLocal), true);
                    if (FollowPath(dt, 0.35f))
                    {
                        transform.SetParent(ship, true);
                        ReturnToStation();
                    }
                    break;
            }
        }

        void ReturnToStation()
        {
            transform.localPosition = stationLocal;
            transform.localRotation = Quaternion.identity;
            heaveCooldown = heaveInterval.x;
            state = State.Station;
        }

        /// A pace inboard of their post — clear of the gun, and derived from
        /// their own station so five people never bail on the same spot.
        Vector3 BailLocal => new Vector3(
            stationLocal.x * (1f - bailStepInboard), stationLocal.y, stationLocal.z);

        /// Retching is on a timer of its own and never touches the state
        /// machine: they heave where they stand and keep working.
        void TickHeaving(float dt)
        {
            if (heaveTimer > 0f) { heaveTimer -= dt; return; }

            // `Puppeted` for the same reason `TrackSickness` reads it: a hand
            // at a camp is `Station`, so without this a crewman left ashore
            // still green from the crossing would retch in the middle of the
            // village — and `ActBody` no longer has the rotation to show it
            // with, so it would be a counter going up and nothing on screen.
            if (!IsAboard || Puppeted || Sickness01 < HeaveAt)
            {
                heaveCooldown = heaveInterval.x;
                return;
            }

            heaveCooldown -= dt;
            if (heaveCooldown <= 0f)
            {
                heaveTimer = heaveLength;
                heaveCooldown = Mathf.Lerp(heaveInterval.x, heaveInterval.y, Severity01);
                PukeCount++;
            }
        }

        /// Travel horizontally toward a world target, riding the water surface
        /// while over open sea. Arrival is judged on HORIZONTAL distance only:
        /// the deck sits about 2m above the waterline, so a 3D distance test
        /// could never be satisfied while the wading code pins them to the
        /// surface — which left recalled crew walking forever.
        // --- Waypoint routing ---
        // Crew must use the plank rather than cutting across open water, so
        // every trip between ship and shore is routed through its two ends.
        readonly List<Vector3> path = new List<Vector3>();
        int pathIndex;
        bool onPlank;

        void SetPath(params Vector3[] points)
        {
            path.Clear();
            foreach (var p in points) path.Add(p);
            pathIndex = 0;
        }

        /// Route from wherever we are, over the plank, to a point on the ship.
        void PathToShip(Vector3 finalPoint)
        {
            if (gangway != null && gangway.Ready)
                SetPath(gangway.LandingPoint, gangway.DeckPoint, finalPoint);
            else
                SetPath(finalPoint);
        }

        /// Route from the deck, over the plank, to a point ashore.
        void PathToShore(Vector3 finalPoint)
        {
            if (gangway != null && gangway.Ready)
                SetPath(gangway.DeckPoint, gangway.LandingPoint, finalPoint);
            else
                SetPath(finalPoint);
        }

        /// The ship rides the swell, so any waypoint attached to it — the plank's
        /// deck end and the destination on board — has to be re-read each frame
        /// or the crew walk to where the ship used to be.
        void RefreshShipWaypoints(Vector3 finalPoint, bool updateFinal)
        {
            if (path.Count == 0) return;
            if (path.Count >= 3 && gangway != null && gangway.Ready)
                path[1] = gangway.DeckPoint;
            if (updateFinal) path[path.Count - 1] = finalPoint;
        }

        bool FollowPath(float dt, float finalStandOff)
        {
            if (path.Count == 0) return true;
            bool last = pathIndex >= path.Count - 1;
            // Intermediate points are plank ends: hug them so the crew stay on
            // the timber instead of clipping the corner over the water.
            onPlank = !last || path.Count > 1;
            if (WalkNear(path[pathIndex], last ? finalStandOff : 0.6f, dt))
            {
                if (last) { onPlank = false; return true; }
                pathIndex++;
            }
            return false;
        }

        /// Walk toward a point but stop `standOff` metres short of it.
        bool WalkNear(Vector3 target, float standOff, float dt)
        {
            Vector3 flat = target - transform.position;
            flat.y = 0f;
            float dist = flat.magnitude;
            if (dist <= standOff) return true;
            Vector3 aim = target - flat.normalized * standOff;
            return WalkToWorld(aim, dt) || dist <= standOff;
        }

        bool WalkToWorld(Vector3 target, float dt)
        {
            Vector3 pos = transform.position;
            Vector3 flatPos = new Vector3(pos.x, 0f, pos.z);
            Vector3 flatTarget = new Vector3(target.x, 0f, target.z);
            Vector3 next = Vector3.MoveTowards(flatPos, flatTarget, shoreWalkSpeed * dt);
            float horizontal = Vector3.Distance(next, flatTarget);

            if (horizontal < 0.35f)
            {
                transform.position = target;   // snap: guarantees arrival
                return true;
            }

            float y;
            if (onPlank || horizontal < 4f)
            {
                // On the plank, follow its slope between the two ends instead
                // of riding the water underneath it.
                y = Mathf.Lerp(pos.y, target.y, 1f - Mathf.Exp(-6f * dt));
            }
            else
            {
                // **Follow the ground under their FEET, not the height of
                // wherever they are going.**
                //
                // This was `y = target.y`, held for the whole walk: a crew
                // member setting off for a tree sixty metres up the hill
                // popped to sixty metres on the first step and glided there
                // through the air, then sank into the slope on the way back
                // down with the ship's height. Measured across a shore party
                // on Island_1, against a raycast onto the drawn mesh: **mean
                // 30 m off the ground, worst 94 m.**
                //
                // Sampled, not smoothed. The height field is continuous and
                // they walk at a couple of metres a second, so following it
                // exactly cannot jitter — and a lag here would trade a fixed
                // error for one that grows with the slope they are crossing.
                // That is why the 10 Hz terrain tick below interpolates toward
                // where they are GOING rather than holding the last value.
                y = target.y;

                // The handle follows their feet whether or not the sea is what
                // is under them, so the first frame they step off a beach
                // reads a height taken beside them rather than wherever they
                // last waded.
                EnsureProbe();
                seaProbe.position = next;

                // Which island, twice a second. The shoreline test against it
                // still runs every frame — see the field comments.
                if (Time.time >= nextIsleLookup)
                {
                    footingIsle = World.Island.Nearest(next);
                    nextIsleLookup = Time.time + IsleInterval;
                }

                var isle = footingIsle;
                if (isle != null)
                {
                    Vector3 flat = next - isle.transform.position;
                    flat.y = 0f;
                    // Against the shoreline on THIS bearing. The mean radius
                    // called half a lobed island "sea" and floated them home
                    // on the swell across dry land.
                    float shore = isle.RadiusAt(Mathf.Atan2(flat.x, flat.z));
                    if (flat.magnitude > shore)
                    {
                        // Wading: the sea's height comes off the registry's
                        // batched Burst query, one physics step old. At
                        // 6.5 m/s that is 13 cm of walking under a surface
                        // they are standing 35 cm proud of anyway.
                        if (seaProbe.sampledFrame != 0) y = seaProbe.sample.height + 0.35f;
                        else if (Ocean.OceanSampler.Ready)
                            // First frame only — nothing batched for this hand yet.
                            y = Ocean.OceanSampler.SampleImmediate(next).height + 0.35f;
                    }
                    else if (World.Island.TerrainHeight != null)
                    {
                        y = Footing(next, flatTarget - next);
                    }
                }
            }

            transform.position = new Vector3(next.x, y, next.z);
            Vector3 look = flatTarget - next;
            if (look.sqrMagnitude > 0.01f)
                transform.rotation = Quaternion.Slerp(transform.rotation,
                    Quaternion.LookRotation(look, Vector3.up), 1f - Mathf.Exp(-6f * dt));
            return false;
        }

        /// The ground under their feet, from a terrain sample taken 10 times a
        /// second instead of every frame.
        ///
        /// Each tick samples the height where the tick will END — one step of
        /// `toTarget`, clamped to how far they can actually walk in the
        /// interval — and the frames in between run the straight line from the
        /// last tick's end to this one's. On a straight leg, which is what
        /// WalkToWorld does between waypoints, that lands exactly on the
        /// sampled field with no lag at all; only a turn inside a tick costs
        /// anything, and it costs at most that tick.
        ///
        /// `groundHeld` alone is not enough to continue from: a hand who has
        /// been aboard for a minute would resume from a height sampled on
        /// another island. A gap of more than one tick re-anchors.
        float Footing(Vector3 here, Vector3 toTarget)
        {
            float now = Time.time;
            if (now >= groundTickEnd)
            {
                bool continuous = groundHeld && now < groundTickEnd + GroundInterval;
                groundFrom = continuous ? groundTo : World.Island.TerrainHeight(here.x, here.z);

                Vector3 step = toTarget;
                step.y = 0f;
                float reach = shoreWalkSpeed * GroundInterval;
                if (step.sqrMagnitude > reach * reach) step = step.normalized * reach;
                Vector3 ahead = here + step;

                groundTo = World.Island.TerrainHeight(ahead.x, ahead.z);
                groundTickEnd = now + GroundInterval;
                groundHeld = true;
            }
            return Mathf.Lerp(groundTo, groundFrom,
                Mathf.Clamp01((groundTickEnd - now) / GroundInterval));
        }

        bool WalkTo(Vector3 targetLocal, float dt)
        {
            Vector3 pos = Vector3.MoveTowards(transform.localPosition, targetLocal, walkSpeed * dt);
            transform.localPosition = pos;
            return (pos - targetLocal).sqrMagnitude < 0.001f;
        }

        void ActBody(float dt)
        {
            // Queasy sway: builds with sickness, wobbles faster when sicker.
            swayPhase += dt * Mathf.Lerp(1.2f, 3.2f, Sickness01);
            float sway = Mathf.Sin(swayPhase) * maxSwayDegrees * Sickness01;

            // **Somebody else owns this body's rotation.** Every branch below
            // writes `localRotation` outright, and a puppeted hand is being
            // walked to a sawmill by `World.CampWorker` or dangled from the
            // Hand — either of which would be fought frame by frame, which is
            // exactly what made the camp's villagers face the wrong way. The
            // tint underneath is NOT guarded: it is additive, it is the only
            // thing that reads the weather on their faces, and `VillagerActing`
            // deliberately stays off that channel so nothing double-books it.
            if (Puppeted) { /* pose is not ours */ }
            else if (heaveTimer > 0f && IsAboard)
            {
                // Doubled over the side where they stand — gun crews are at
                // their own gunport anyway. Big pose: it has to read from the
                // chase camera ~30m back, not just up close.
                float heave = Mathf.Sin(Time.time * 7f) * 8f;
                float outward = Mathf.Sign(railLocal.x != 0f ? railLocal.x : 1f);
                transform.localRotation = Quaternion.Euler(0f, 90f * outward, 0f)
                    * Quaternion.Euler(52f + heave, 0f, 0f);
            }
            else if (state == State.Bailing)
            {
                // Scoop and fling: bend, twist outboard, throw it over. Fast
                // and rhythmic, so a deck full of bailing crew reads as panic.
                float scoop = Mathf.Sin(Time.time * 4.2f + swayPhase);
                float outward = Mathf.Sign(stationLocal.x != 0f ? stationLocal.x : 1f);
                transform.localRotation =
                    Quaternion.Euler(0f, 40f * outward * Mathf.Max(0f, scoop), 0f)
                    * Quaternion.Euler(38f + 26f * scoop, 0f, 0f);
            }
            else if (state == State.Station)
            {
                transform.localRotation = Quaternion.Euler(0f, 0f, sway);
            }

            // Green shift: the sea's mood, written on the crew. Nothing about
            // it costs the player anything.
            // Built on demand: crew are instantiated and re-parented at
            // runtime, so Update can reach here before Start has run.
            if (block == null) block = new MaterialPropertyBlock();
            if (tintRenderers == null || tintRenderers.Length == 0)
                tintRenderers = FindSkinRenderers();

            Color tint = Color.Lerp(healthyTint, sickTint, Mathf.Clamp01(Sickness01 * 1.15f));
            block.SetColor(BaseColorId, tint);
            foreach (var r in tintRenderers)
                if (r != null) r.SetPropertyBlock(block);
        }
    }
}
