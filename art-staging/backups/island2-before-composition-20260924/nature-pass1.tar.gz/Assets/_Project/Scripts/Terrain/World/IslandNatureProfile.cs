using System;
using System.Collections.Generic;
using UnityEngine;
using SeaSick.World;

namespace SeaSick.Terrain
{
    /// Optional, island-local art treatment. Resource placement and accounting stay owned by the existing scatter.
    [DefaultExecutionOrder(-1100)]
    public sealed class IslandNatureProfile : MonoBehaviour
    {
        [SerializeField] Vector2 islandCentre = new Vector2(660, 81);
        [SerializeField] TextAsset meshLibrary;
        [SerializeField] Material natureMaterial;
        public Material Material => natureMaterial;
        public static IslandNatureProfile Active { get; private set; }
        readonly Dictionary<string, SceneryKit.Template> templates = new Dictionary<string, SceneryKit.Template>();
        readonly Dictionary<string, Mesh> resourceMeshes = new Dictionary<string, Mesh>();
        Texture2D ground;
        [Serializable] public class Library { public Entry[] entries; }
        [Serializable] public class Entry
        {
            public string name;
            public Vector3[] vertices, normals;
            public Color[] colors;
            public int[] triangles;
        }
        void OnEnable()
        {
            Active = this;
            templates.Clear();
            if (meshLibrary == null || natureMaterial == null) return;
            var data = JsonUtility.FromJson<Library>(meshLibrary.text);
            foreach (var e in data.entries)
            {
                if (e.vertices.Length != e.normals.Length || e.vertices.Length != e.colors.Length)
                    throw new InvalidOperationException("Invalid nature template " + e.name);
                var tp = new SceneryKit.Template { name=e.name,v=e.vertices,n=e.normals,t=e.triangles,c=new Color32[e.colors.Length] };
                for (int i=0;i<tp.v.Length;i++)
                {
                    tp.c[i]=e.colors[i];
                    tp.height=Mathf.Max(tp.height,tp.v[i].y);
                    tp.radius=Mathf.Max(tp.radius,new Vector2(tp.v[i].x,tp.v[i].z).magnitude);
                }
                templates.Add(e.name,tp);
            }
        }
        void OnDisable()
        {
            if (Active==this) { Active=null; Shader.SetGlobalFloat("_IslandNatureEnabled",0); }
            if (ground!=null) Destroy(ground);
            foreach(var mesh in resourceMeshes.Values) if(mesh!=null) Destroy(mesh);
            resourceMeshes.Clear();
        }
        public static IslandNatureProfile For(Vector3 centre)
        {
            var p=Active;
            return p!=null && p.isActiveAndEnabled && p.templates.Count>0
                && Vector2.Distance(p.islandCentre,new Vector2(centre.x,centre.z))<1f ? p : null;
        }
        public SceneryKit.Template Get(string name) => templates.TryGetValue(name,out var t) ? t : null;

        public void DressResource(GameObject root,string kind,int ordinal)
        {
            if(kind!="Stone" && kind!="Timber") return;
            string id=kind=="Stone" ? (ordinal%3==0 ? "Boulder_Broad" : ordinal%3==1 ? "Boulder_Long" : "Boulder_Low") : "Forest_Hornbeam";
            var tp=Get(id); if(tp==null) return;
            if(!resourceMeshes.TryGetValue(id,out var mesh))
            {
                mesh=new Mesh {name="Island2_"+id,vertices=tp.v,normals=tp.n,colors32=tp.c,triangles=tp.t};
                mesh.RecalculateBounds();resourceMeshes.Add(id,mesh);
            }
            // Retain root identity and existing interaction components; only replace the visible mesh.
            foreach(var renderer in root.GetComponentsInChildren<MeshRenderer>(true))
            {
                renderer.enabled=false;
                renderer.forceRenderingOff=true; // Gather/regrow toggles enabled on every renderer.
            }
            var visual=new GameObject("Nature resource visual");visual.transform.SetParent(root.transform,false);
            visual.AddComponent<MeshFilter>().sharedMesh=mesh;
            visual.AddComponent<MeshRenderer>().sharedMaterial=natureMaterial;
        }

        public SceneryKit.Template Resolve(string old)
        {
            bool low=old.EndsWith("_LOD1",StringComparison.Ordinal);
            string id=low ? old.Substring(0,old.Length-5) : old;
            string mapped=null;
            if(id.StartsWith("Scrub_",StringComparison.Ordinal)) mapped="Coast_WindScrub";
            else if(id.StartsWith("Boulder_",StringComparison.Ordinal))
                mapped=id=="Boulder_0" ? "Boulder_Broad" : id=="Boulder_1" ? "Boulder_Low" : "Boulder_Long";
            else if(id.StartsWith("Cliff_",StringComparison.Ordinal)) mapped=id=="Cliff_1" ? "Cliff_BrokenSlab" : "Cliff_LowLedge";
            else switch(id)
            {
                case "Spruce": mapped="Forest_Pine"; break;
                case "Broad": mapped="Forest_Hornbeam"; break;
                case "Palm": mapped="Forest_PalmStraight"; break;
                case "Grass": mapped="Grass_Fan"; break;
                case "Grass_B": mapped="Grass_Sparse"; break;
                case "Grass_Dry": mapped="Coast_DuneGrass"; break;
                case "Fern": mapped="Broadleaf_Rosette"; break;
                case "Fern_B": mapped="Forest_Bracken"; break;
                case "Sticks": mapped="Twig_Fork"; break;
                case "Driftwood": mapped="Shore_ForkedDriftwood"; break;
            }
            if(mapped==null) return SceneryKit.Get(old);
            var tp=Get(mapped+(low ? "_LOD1" : "")) ?? Get(mapped);
            // Legacy rock stamps scale unit-sized forms into large outcrops.
            if(id.StartsWith("Cliff_",StringComparison.Ordinal) || id.StartsWith("Boulder_",StringComparison.Ordinal))
            {
                string key="Unit_"+mapped;
                if(templates.TryGetValue(key,out var unit)) return unit;
                Vector3 min=tp.v[0],max=min;
                foreach(var p in tp.v){ min=Vector3.Min(min,p);max=Vector3.Max(max,p); }
                Vector3 size=max-min;
                unit=new SceneryKit.Template { name=key,v=new Vector3[tp.v.Length],n=new Vector3[tp.n.Length],c=tp.c,t=tp.t,height=1,radius=.8f };
                for(int i=0;i<tp.v.Length;i++)
                {
                    unit.v[i]=new Vector3(tp.v[i].x/size.x,tp.v[i].y/size.y,tp.v[i].z/size.z);
                    unit.n[i]=Vector3.Scale(tp.n[i],size).normalized;
                }
                templates.Add(key,unit); return unit;
            }
            return tp;
        }
        public SceneryKit.Template Tree(Vector3 at,float roll,float cover,float slope,bool low=false)
        {
            float grove=Mathf.PerlinNoise(at.x*.022f+41,at.z*.022f+83);
            string name;
            if(at.y<7f && slope<.25f)
                name=roll<.35f ? "PalmStraight" : roll<.7f ? "PalmLeaning" : roll<.9f ? "PalmShort" : "PalmTall";
            else if(slope>.5f || (at.y>24 && grove>.57f)) name=roll<.7f ? "Pine" : "Coastal";
            else if(cover<.45f && roll<.38f) name="Young";
            else if(grove<.36f) name=roll<.7f ? "Birch" : "Slender";
            else if(grove>.65f) name=roll<.55f ? "Oak" : "Broadleaf";
            else name=roll<.38f ? "Hornbeam" : roll<.61f ? "Broadleaf" : roll<.8f ? "Uneven" : roll<.93f ? "Slender" : "Leaning";
            return Get("Forest_"+name+(low ? "_LOD1" : ""));
        }

        public struct Accent { public string name; public Vector3 position; public float yaw,scale; }
        public IEnumerable<Accent> Accents(Vector3 centre,float radius,Func<float,float,float> height,Func<float,float> radiusAt)
        {
            for(float z=-radius;z<radius;z+=13)
            for(float x=-radius;x<radius;x+=13)
            {
                float px=centre.x+x+3*Mathf.Sin(z*1.71f),pz=centre.z+z+3*Mathf.Sin(x*2.31f);
                if(new Vector2(px-centre.x,pz-centre.z).magnitude>radiusAt(Mathf.Atan2(px-centre.x,pz-centre.z))*.98f) continue;
                float h=height(px,pz);
                if(h<2.4f) continue;
                float slope=Mathf.Max(Mathf.Abs(height(px+2,pz)-height(px-2,pz)),Mathf.Abs(height(px,pz+2)-height(px,pz-2)))/4;
                float patch=Mathf.PerlinNoise(px*.061f+23,pz*.061f+37);
                float roll=Mathf.Repeat(Mathf.Sin(px*12.9898f+pz*78.233f)*43758.5453f,1);
                string id=null;
                if(h<5.5f && slope<.25f && patch>.52f) id=roll<.12f ? "Shore_ForkedDriftwood" : roll<.4f ? "Shore_WashedStones" : "Coast_DuneGrass";
                else if(h>6 && slope>.18f && slope<.65f && patch>.60f) id=roll<.35f ? "Cliff_BrokenSlab" : "Cliff_TalusCluster";
                else if(h>6 && slope<.3f && patch>.65f) id=roll<.08f ? "Forest_FallenTrunk" : roll<.4f ? "Forest_Bracken" : "Grass_Fan";
                if(id!=null) yield return new Accent {name=id,position=new Vector3(px,h-.055f,pz),yaw=roll*Mathf.PI*2,scale=.85f+patch*.5f};
            }
        }

        static Color Palette(string hex) { ColorUtility.TryParseHtmlString(hex,out var c); return c.linear; }
        public void PaintGround(Island island,List<SceneryWood.Tree> trees,Func<float,float,float> height)
        {
            const int N=256;
            float span=island.MaxRadius*2+20;
            var cover=new float[N*N]; var roots=new float[N*N];
            foreach(var tree in trees)
            {
                int tx=Mathf.RoundToInt(((tree.baseAt.x-islandCentre.x)/span+.5f)*(N-1));
                int tz=Mathf.RoundToInt(((tree.baseAt.z-islandCentre.y)/span+.5f)*(N-1));
                for(int dz=-5;dz<=5;dz++) for(int dx=-5;dx<=5;dx++)
                {
                    int x=tx+dx,z=tz+dz; if(x<0 || z<0 || x>=N || z>=N) continue;
                    float d=(dx*dx+dz*dz)*span*span/(N*N);
                    cover[z*N+x]+=Mathf.Exp(-d/60f);
                    roots[z*N+x]=Mathf.Max(roots[z*N+x],Mathf.Exp(-d/11f));
                }
            }
            var pixels=new Color[N*N];
            Color grass=Palette("#909C51"),dry=Palette("#B0B565"),moss=Palette("#557A47"),earth=Palette("#9C8058");
            for(int z=0;z<N;z++) for(int x=0;x<N;x++)
            {
                float px=islandCentre.x+(x/(N-1f)-.5f)*span,pz=islandCentre.y+(z/(N-1f)-.5f)*span;
                var delta=new Vector2(px-islandCentre.x,pz-islandCentre.y);
                float inside=island.RadiusAt(Mathf.Atan2(delta.x,delta.y))-delta.magnitude;
                int i=z*N+x; float noise=Mathf.PerlinNoise(px*.047f+7,pz*.047f+11);
                var c=Color.Lerp(grass,dry,Mathf.SmoothStep(0,1,(noise-.35f)*2));
                c=Color.Lerp(c,moss,Mathf.Clamp01(cover[i]*.36f)*.8f);
                c=Color.Lerp(c,earth,Mathf.Clamp01((roots[i]+noise*.4f-.25f)*1.1f)*.72f);
                c.a=Mathf.Clamp01(inside/8f); pixels[i]=c;
            }
            if(ground!=null) Destroy(ground);
            ground=new Texture2D(N,N,TextureFormat.RGBA32,false,true) {name="Island 2 natural ground",wrapMode=TextureWrapMode.Clamp,filterMode=FilterMode.Bilinear};
            ground.SetPixels(pixels);ground.Apply(false,true);
            Shader.SetGlobalTexture("_IslandNatureGround",ground);
            Shader.SetGlobalVector("_IslandNatureBounds",new Vector4(islandCentre.x,islandCentre.y,span,1/span));
            Shader.SetGlobalFloat("_IslandNatureEnabled",1);
        }
    }
}
